<!-- Define an associative array and output array elements on the screen. 
Use for this cartoon/anime/game characters (like Mickey Mouse, Super Mario, Goku, Pokemon etc.). 

Transform this code into a solution done with multidimensional arrays 
to track different properties of the characters. (hint: in order to output nicely (user friendly) 
your solutions on the browser you will need the HTML tags for it). -->

<?php
    // part 1
    $arr = [
        "cartoon" => "mickey mouse",
        "anime" => "son goku",
        "game" => "mario mario"
    ];

    echo $arr["cartoon"]."<br>";
    echo $arr["anime"]."<br>";
    echo $arr["game"]."<br>";

    // part 2
    // using the same var will overwrite the old one
    $arr = [
        "cartoon" => [
            "name" => "mickey mouse",
            "age" => "old",
            "height" => 120
        ],
        "anime" => [
            "name" => "son goku",
            "age" => 30,
            "height" => 180
        ],
        "game" => [
            "name" => "mario mario",
            "age" => "moustache age",
            "height" => "about 32 pixels"
        ]
    ];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border="1">
        <tr>
            <th>Name:</th>
            <th>Age:</th>
            <th>Height:</th>
        </tr>
        <tr>
            <td><?= $arr["cartoon"]["name"]; ?></td>
            <td><?= $arr["cartoon"]["age"]; ?></td>
            <td><?= $arr["cartoon"]["height"]; ?></td>
        </tr>
    </table>

    <br>

    <table border="1">
        <tr>
            <th>Name:</th>
            <th>Age:</th>
            <th>Height:</th>
        </tr>
        <tr>
            <td><?= $arr["anime"]["name"]; ?></td>
            <td><?= $arr["anime"]["age"]; ?></td>
            <td><?= $arr["anime"]["height"]; ?></td>
        </tr>
    </table>

    <br>

    <table border="1">
        <tr>
            <th>Name:</th>
            <th>Age:</th>
            <th>Height:</th>
        </tr>
        <tr>
            <td><?= $arr["game"]["name"]; ?></td>
            <td><?= $arr["game"]["age"]; ?></td>
            <td><?= $arr["game"]["height"]; ?></td>
        </tr>
    </table>
</body>
</html>