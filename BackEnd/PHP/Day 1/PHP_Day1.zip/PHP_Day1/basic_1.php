<!-- Exercise 1
Print your name in an h1 HTML element using PHP (define the variable and store your name into it). 
Use external CSS to position your name in the middle of the screen (horizontal, vertical). -->

<?php
    $name = "MJ";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *, *::after, *::before {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
    </style>
</head>
<body>
    <h1><?php echo $name; ?></h1>
</body>
</html>