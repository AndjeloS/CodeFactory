<?php
    // EXERCISE 2
    // create a couple of variables, name, age, and job title, and after that, 
    // you print a message on the screen "hi, my name is NAME, and i am AGE, and i work as a JOB_TITLE"
    $name = "MJ";
    $age = 31;
    $job_title = "dev";

    echo "hi, my name is $name, and i am $age, and i work as a $job_title";

    // just for a break
    echo "<br>";

    
    // EXERCISE 3
    // create an array that has names Mark, John, Georg and Lisa, print the 3rd player on the screen like this: 
    // "the third player in the team is 3rd_player".
    $arr = ["Mark", "John", "Georg", "Lisa"];
    echo "the third player in the team is $arr[2]";